l = [1,2,3]
p = [1,2,3]

if l==p:
    print ("H")