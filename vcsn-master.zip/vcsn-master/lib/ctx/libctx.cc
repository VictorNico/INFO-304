#define BUILD_LIBVCSN 1
// Instantiate many algorithms, not just the core ones.
#define VCSN_INSTANTIATION 2
#define MAYBE_EXTERN
#define HEADER <vcsn/ctx/CTX.hh>
#include HEADER
