# Package interface.
from vcsn.demo.eliminate_state import *
from vcsn.demo.automaton import *
