<?php

$dir = $argv[1];

$env = file_get_contents($dir . '/.env');
$env = str_replace('DB_CONNECTION=mysql', 'DB_CONNECTION=sqlite', $env);
$env = str_replace('DB_HOST=127.0.0.1', '', $env);
$env = str_replace('DB_PORT=3306', '', $env);
$env = str_replace('DB_DATABASE=laravel', '', $env);
$env = str_replace('DB_USERNAME=root', '', $env);
$env = str_replace('DB_PASSWORD=', '', $env);

file_put_contents($dir . '/.env', $env);